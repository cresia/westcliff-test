const circle = require('./node-example2.js');
console.log(`The area of a circle of radius 4 is ${circle.area(4)}`);
